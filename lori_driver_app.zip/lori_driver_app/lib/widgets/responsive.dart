import 'package:flutter/material.dart';

class Breakpoints {
  static const double tablet = 600;
  static const double desktop = 900;
  static const double largeDesktop = 1280;
}

class ResponsiveContainer extends StatelessWidget {
  const ResponsiveContainer({super.key, required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    double maxWidth = double.infinity;
    if (width >= Breakpoints.largeDesktop) {
      maxWidth = 1200;
    } else if (width >= Breakpoints.desktop) {
      maxWidth = 1000;
    } else if (width >= Breakpoints.tablet) {
      maxWidth = 800;
    }
    return Align(
      alignment: Alignment.topCenter,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: maxWidth),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: child,
        ),
      ),
    );
  }
}



