import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../orders/providers/order_providers.dart';
import '../../orders/data/order.dart';
import '../../orders/data/products.dart';
import '../../../widgets/responsive.dart';

class ManagerOrderDetailsPage extends ConsumerWidget {
  const ManagerOrderDetailsPage({super.key, required this.orderId});
  final String orderId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final orders = ref.watch(ordersProvider);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detalle del pedido'),
        centerTitle: true,
      ),
      body: orders.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, st) => Center(child: Text('Error: $e')),
        data: (list) {
          final order = list.firstWhere((o) => o.id == orderId, orElse: () =>
              Order(id: orderId, address: '-', latitude: 0, longitude: 0, clientName: '-', clientPhone: '-', delivered: false));
          final shortId = order.id.length > 4 ? order.id.substring(order.id.length - 4) : order.id;
          final products = generateProductsForOrder(order.id);
          final mapsUri = Uri.parse('https://www.google.com/maps/search/?api=1&query=${order.latitude},${order.longitude}');
          final telUri = Uri.parse('tel:${order.clientPhone}');
          final waUri = Uri.parse('https://wa.me/${order.clientPhone.replaceAll("+", "").replaceAll(" ", "")}');

          return ResponsiveContainer(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
              Card(
                child: ListTile(
                  title: Text('Pedido #$shortId • ${order.clientName}'),
                  subtitle: Text(order.address),
                ),
              ),
              const SizedBox(height: 8),
              LayoutBuilder(
                builder: (context, constraints) {
                  final wide = constraints.maxWidth >= Breakpoints.desktop;
                  if (wide) {
                    return Row(
                      children: [
                        Expanded(
                          child: FilledButton.icon(
                            onPressed: () => launchUrl(mapsUri, mode: LaunchMode.externalApplication),
                            icon: const Icon(Icons.map_outlined),
                            label: const Text('Abrir mapa'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: FilledButton.icon(
                            onPressed: () => launchUrl(telUri),
                            icon: const Icon(Icons.call_outlined),
                            label: const Text('Llamar'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: FilledButton.tonalIcon(
                            onPressed: () => launchUrl(waUri, mode: LaunchMode.externalApplication),
                            icon: const Icon(Icons.chat_outlined),
                            label: const Text('Enviar WhatsApp al cliente'),
                          ),
                        ),
                      ],
                    );
                  }
                  return Column(
                    children: [
                      FilledButton.icon(
                        onPressed: () => launchUrl(mapsUri, mode: LaunchMode.externalApplication),
                        icon: const Icon(Icons.map_outlined),
                        label: const Text('Abrir mapa'),
                      ),
                      const SizedBox(height: 8),
                      FilledButton.icon(
                        onPressed: () => launchUrl(telUri),
                        icon: const Icon(Icons.call_outlined),
                        label: const Text('Llamar'),
                      ),
                      const SizedBox(height: 8),
                      FilledButton.tonalIcon(
                        onPressed: () => launchUrl(waUri, mode: LaunchMode.externalApplication),
                        icon: const Icon(Icons.chat_outlined),
                        label: const Text('Enviar WhatsApp al cliente'),
                      ),
                    ],
                  );
                },
              ),
              const SizedBox(height: 16),
              Text('Productos', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              Card(
                child: ListView.separated(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemBuilder: (_, i) {
                    final p = products[i];
                    return ListTile(
                      title: Text(p.name),
                      trailing: Text('x${p.quantity}'),
                    );
                  },
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemCount: products.length,
                ),
              ),
              const SizedBox(height: 16),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text('Aviso importante', style: TextStyle(fontWeight: FontWeight.w600)),
                      SizedBox(height: 6),
                      Text('Este pedido forma parte del sistema de logística de Concreto Group. Los datos del cliente se utilizan únicamente para coordinar la entrega.'),
                    ],
                  ),
                ),
              ),
            ],
            ),
          );
        },
      ),
    );
  }
}


