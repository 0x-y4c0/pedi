import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../orders/providers/order_providers.dart';
import '../../orders/data/order.dart';
import '../../../utils/geo.dart';
import '../../../widgets/responsive.dart';

class ManagerPage extends ConsumerStatefulWidget {
  const ManagerPage({super.key});

  @override
  ConsumerState<ManagerPage> createState() => _ManagerPageState();
}

class _ManagerPageState extends ConsumerState<ManagerPage> {
  bool _isReordering = false;
  String? _filterAssignee; // null = Todos, 'chofer1' or 'chofer2'

  @override
  Widget build(BuildContext context) {
    final ordersAsync = ref.watch(ordersProvider);
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        if (context.mounted) {
          context.go('/login');
        }
      },
      child: Scaffold(
        appBar: AppBar(
        title: const Text('Manager'),
        centerTitle: true,
        actions: [
          TextButton.icon(
            onPressed: _filterAssignee == null
                ? null
                : () => setState(() => _isReordering = !_isReordering),
            icon: Icon(_isReordering ? Icons.check_circle_outline : Icons.sort),
            label: Text(_isReordering ? 'Hecho' : 'Ordenar'),
          ),
          const SizedBox(width: 8),
          PopupMenuButton<String?>(
            tooltip: 'Filtrar por chofer',
            onSelected: (v) => setState(() {
              _filterAssignee = v;
              _isReordering = false;
            }),
            itemBuilder: (context) => const [
              PopupMenuItem(value: null, child: Text('Todos')),
              PopupMenuItem(value: 'chofer1', child: Text('Chofer 1')),
              PopupMenuItem(value: 'chofer2', child: Text('Chofer 2')),
            ],
            child: const Padding(
              padding: EdgeInsets.symmetric(horizontal: 8),
              child: Icon(Icons.filter_list),
            ),
          ),
          IconButton(
            tooltip: 'Ir a inicio de sesión',
            icon: const Icon(Icons.person_outline),
            onPressed: () {
              context.go('/login');
            },
          ),
        ],
        ),
        body: ordersAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, st) => Center(child: Text('Error: $e')),
        data: (orders) {
          final list = _filterAssignee == null
              ? orders
              : orders.where((o) => o.assignedTo == _filterAssignee).toList();
          if (orders.isEmpty) {
              return const ResponsiveContainer(child: _ManagerEmpty());
          }
          if (_isReordering && _filterAssignee != null) {
            return ResponsiveContainer(
              child: ReorderableListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: list.length,
                onReorder: (oldIndex, newIndex) async {
                  await ref.read(ordersProvider.notifier).reorderAssigned(_filterAssignee, oldIndex, newIndex);
                },
                itemBuilder: (context, index) {
                  final o = list[index];
                  final shortId = o.id.length > 4 ? o.id.substring(o.id.length - 4) : o.id;
                  final asignado = o.assignedTo == null
                      ? 'Sin asignar'
                      : (o.assignedTo == 'chofer1' ? 'Chofer 1' : 'Chofer 2');
                  return Card(
                    key: ValueKey(o.id),
                    child: ListTile(
                      title: Text('Pedido #$shortId'),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(o.address, maxLines: 1, overflow: TextOverflow.ellipsis),
                          Text('${o.clientName} • ${o.clientPhone}',
                              style: Theme.of(context).textTheme.bodySmall,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis),
                        ],
                      ),
                      trailing: Chip(label: Text(asignado)),
                    ),
                  );
                },
              ),
            );
          }
          return ResponsiveContainer(
            child: ListView.separated(
              padding: const EdgeInsets.all(12),
              itemBuilder: (context, index) {
                final o = list[index];
              final shortId = o.id.length > 4 ? o.id.substring(o.id.length - 4) : o.id;
              final asignado = o.assignedTo == null
                  ? 'Sin asignar'
                  : (o.assignedTo == 'chofer1' ? 'Chofer 1' : 'Chofer 2');
              return Card(
                child: ListTile(
                  title: Text('Pedido #$shortId'),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(o.address, maxLines: 1, overflow: TextOverflow.ellipsis),
                      Text('${o.clientName} • ${o.clientPhone}',
                          style: Theme.of(context).textTheme.bodySmall,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis),
                    ],
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Chip(label: Text(asignado)),
                      const SizedBox(width: 8),
                      IconButton(
                        tooltip: 'Editar',
                        icon: const Icon(Icons.edit_outlined),
                        onPressed: () async {
                          final updated = await showModalBottomSheet<Order>(
                            context: context,
                            isScrollControlled: true,
                            builder: (context) => _OrderEditor(existing: o),
                          );
                          if (updated != null) {
                            await ref.read(ordersProvider.notifier).updateOrder(updated);
                          }
                        },
                      ),
                    ],
                  ),
                  onTap: () {
                    context.push('/manager/order/${o.id}');
                  },
                  onLongPress: () async {
                  final choice = await showMenu<String?>(
                    context: context,
                    position: const RelativeRect.fromLTRB(200, 200, 0, 0),
                    items: const [
                      PopupMenuItem(value: 'chofer1', child: Text('Asignar a Chofer 1')),
                      PopupMenuItem(value: 'chofer2', child: Text('Asignar a Chofer 2')),
                      PopupMenuItem(value: null, child: Text('Quitar asignación')),
                    ],
                  );
                  await ref.read(ordersProvider.notifier).assignOrder(o.id, choice);
                  },
                ),
              );
            },
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemCount: orders.length,
            ),
          );
        },
        ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final created = await showModalBottomSheet<Order>(
            context: context,
            isScrollControlled: true,
            builder: (context) => const _OrderEditor(),
          );
          if (created != null) {
            await ref.read(ordersProvider.notifier).addOrder(created);
            if (context.mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Pedido creado')),
              );
            }
          }
        },
        icon: const Icon(Icons.add),
        label: const Text('Nuevo pedido'),
        ),
      ),
    );
  }
}

class _ManagerEmpty extends StatelessWidget {
  const _ManagerEmpty();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.inbox_outlined, size: 48),
          const SizedBox(height: 12),
          Text('No hay pedidos', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 4),
          const Text('Usa el botón + para crear uno nuevo.'),
        ],
      ),
    );
  }
}

class _OrderEditor extends StatefulWidget {
  const _OrderEditor({this.existing});
  final Order? existing;

  @override
  State<_OrderEditor> createState() => _OrderEditorState();
}

class _OrderEditorState extends State<_OrderEditor> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _address;
  late TextEditingController _lat;
  late TextEditingController _lng;
  late TextEditingController _clientName;
  late TextEditingController _clientPhone;
  String? _assignedTo;
  bool _delivered = false;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _address = TextEditingController(text: e?.address ?? '');
    if (e == null) {
      final (lat, lng) = GeoUtils.randomBuenosAiresLatLng();
      _lat = TextEditingController(text: lat.toStringAsFixed(6));
      _lng = TextEditingController(text: lng.toStringAsFixed(6));
    } else {
      _lat = TextEditingController(text: e.latitude.toString());
      _lng = TextEditingController(text: e.longitude.toString());
    }
    _clientName = TextEditingController(text: e?.clientName ?? '');
    _clientPhone = TextEditingController(text: e?.clientPhone ?? '');
    _assignedTo = e?.assignedTo;
    _delivered = e?.delivered ?? false;
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return Padding(
      padding: EdgeInsets.only(bottom: bottom),
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(widget.existing == null ? 'Nuevo pedido' : 'Editar pedido',
                    style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _address,
                  decoration: const InputDecoration(labelText: 'Dirección'),
                  validator: (v) => (v == null || v.isEmpty) ? 'Requerido' : null,
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        controller: _lat,
                        decoration: const InputDecoration(labelText: 'Latitud'),
                        keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
                        validator: (v) => (double.tryParse(v ?? '') == null) ? 'Inválido' : null,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: TextFormField(
                        controller: _lng,
                        decoration: const InputDecoration(labelText: 'Longitud'),
                        keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
                        validator: (v) => (double.tryParse(v ?? '') == null) ? 'Inválido' : null,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                TextFormField(
                  controller: _clientName,
                  decoration: const InputDecoration(labelText: 'Cliente'),
                  validator: (v) => (v == null || v.isEmpty) ? 'Requerido' : null,
                ),
                const SizedBox(height: 8),
                TextFormField(
                  controller: _clientPhone,
                  decoration: const InputDecoration(labelText: 'Teléfono'),
                  validator: (v) => (v == null || v.isEmpty) ? 'Requerido' : null,
                ),
                const SizedBox(height: 8),
                DropdownButtonFormField<String?>(
                  initialValue: _assignedTo,
                  items: const [
                    DropdownMenuItem(value: null, child: Text('Sin asignar')),
                    DropdownMenuItem(value: 'chofer1', child: Text('Chofer 1')),
                    DropdownMenuItem(value: 'chofer2', child: Text('Chofer 2')),
                  ],
                  onChanged: (v) => setState(() => _assignedTo = v),
                  decoration: const InputDecoration(labelText: 'Asignado a'),
                ),
                const SizedBox(height: 8),
                CheckboxListTile(
                  value: _delivered,
                  onChanged: (v) => setState(() => _delivered = v ?? false),
                  title: const Text('Entregado'),
                  controlAffinity: ListTileControlAffinity.leading,
                  contentPadding: EdgeInsets.zero,
                ),
                const SizedBox(height: 16),
                FilledButton(
                  onPressed: () {
                    if (!_formKey.currentState!.validate()) return;
                    final id = widget.existing?.id ?? DateTime.now().millisecondsSinceEpoch.toString();
                    final order = Order(
                      id: id,
                      address: _address.text,
                      latitude: double.parse(_lat.text),
                      longitude: double.parse(_lng.text),
                      clientName: _clientName.text,
                      clientPhone: _clientPhone.text,
                      delivered: _delivered,
                      assignedTo: _assignedTo,
                    );
                    Navigator.of(context).pop(order);
                  },
                  child: Text(widget.existing == null ? 'Crear' : 'Guardar cambios'),
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


