import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../providers/onboarding_providers.dart';

class OnboardingPage extends ConsumerWidget {
  const OnboardingPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const FlutterLogo(size: 96),
            const SizedBox(height: 16),
            Text(
              'Bienvenido a Lori Driver',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 8),
            const Text('Entrega con confianza. Toca para comenzar.'),
            const SizedBox(height: 24),
            FilledButton(
              onPressed: () async {
                await ref.read(onboardingActionsProvider).dismiss();
                if (context.mounted) context.go('/orders');
              },
              child: const Text('Comenzar'),
            ),
          ],
        ),
      ),
    );
  }
}


