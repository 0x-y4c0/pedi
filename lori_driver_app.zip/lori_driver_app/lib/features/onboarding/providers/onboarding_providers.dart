import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

const String _kOnboardingDismissedKey = 'onboarding_dismissed';

final onboardingDismissedProvider = FutureProvider<bool>((ref) async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getBool(_kOnboardingDismissedKey) ?? false;
});

final onboardingActionsProvider = Provider<_OnboardingActions>((ref) {
  return _OnboardingActions();
});

class _OnboardingActions {
  Future<void> dismiss() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kOnboardingDismissedKey, true);
  }
}



