import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../constants/endpoints.dart';

final webhookUrlProvider = Provider<String>((ref) => completeOrderWebhookUrl);



