import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum UserRole { chofer1, chofer2, manager }

String _roleToString(UserRole r) {
  switch (r) {
    case UserRole.chofer1:
      return 'chofer1';
    case UserRole.chofer2:
      return 'chofer2';
    case UserRole.manager:
      return 'manager';
  }
}

UserRole? _stringToRole(String? s) {
  switch (s) {
    case 'chofer1':
      return UserRole.chofer1;
    case 'chofer2':
      return UserRole.chofer2;
    case 'manager':
      return UserRole.manager;
  }
  return null;
}

const String _kUserRoleKey = 'user_role';

class RoleController extends AsyncNotifier<UserRole?> {
  @override
  Future<UserRole?> build() async {
    final prefs = await SharedPreferences.getInstance();
    return _stringToRole(prefs.getString(_kUserRoleKey));
  }

  Future<void> setRole(UserRole role) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kUserRoleKey, _roleToString(role));
    state = AsyncData(role);
  }

  Future<void> clearRole() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_kUserRoleKey);
    state = const AsyncData(null);
  }
}

final roleProvider = AsyncNotifierProvider<RoleController, UserRole?>(
  RoleController.new,
);

