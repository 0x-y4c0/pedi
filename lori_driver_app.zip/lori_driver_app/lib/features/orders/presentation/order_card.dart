import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../data/order.dart';

class OrderCard extends StatelessWidget {
  const OrderCard({super.key, required this.order, required this.onComplete});

  final Order order;
  final VoidCallback onComplete;

  @override
  Widget build(BuildContext context) {
    final shortId = order.id.length > 4 ? order.id.substring(order.id.length - 4) : order.id;
    final mapsUri = Uri.parse(
        'https://www.google.com/maps/search/?api=1&query=${order.latitude},${order.longitude}');
    final telUri = Uri.parse('tel:${order.clientPhone}');

    return Card(
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 56,
              child: Column(
                children: [
                  Text('ID', style: Theme.of(context).textTheme.bodySmall),
                  const SizedBox(height: 2),
                  Text(shortId, style: Theme.of(context).textTheme.titleMedium),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(order.clientName, maxLines: 1, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 4),
                  Text(order.address, maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.bodySmall),
                ],
              ),
            ),
            if (order.delivered)
              const Padding(
                padding: EdgeInsets.only(right: 6),
                child: Chip(label: Text('Entregado')),
              ),
            IconButton(
              tooltip: 'Abrir mapas',
              onPressed: () => launchUrl(mapsUri, mode: LaunchMode.externalApplication),
              icon: const Icon(Icons.map_outlined),
            ),
            IconButton(
              tooltip: 'Llamar al cliente',
              onPressed: () => launchUrl(telUri),
              icon: const Icon(Icons.call_outlined),
            ),
            if (!order.delivered)
              IconButton.filled(
                tooltip: 'Marcar entregado',
                onPressed: onComplete,
                icon: const Icon(Icons.check),
              ),
          ],
        ),
      ),
    );
  }
}


