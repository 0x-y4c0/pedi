import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../providers/order_providers.dart';
import 'order_card.dart';
import '../../../widgets/responsive.dart';
import '../../auth/providers/role_providers.dart';

class OrdersPage extends ConsumerStatefulWidget {
  const OrdersPage({super.key});

  @override
  ConsumerState<OrdersPage> createState() => _OrdersPageState();
}

class _OrdersPageState extends ConsumerState<OrdersPage> {
  bool _isReordering = false;

  @override
  Widget build(BuildContext context) {
    final ordersAsync = ref.watch(driverOrdersProvider);
    final role = ref.watch(roleProvider).value;
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        if (context.mounted) {
          context.go('/login');
        }
      },
      child: Scaffold(
        appBar: AppBar(
        leading: Padding(
          padding: const EdgeInsets.all(8.0),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: Image.asset(
              'assets/logo.png',
              width: 28,
              height: 28,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const FlutterLogo(size: 24),
            ),
          ),
        ),
        title: const Text('Pedidos'),
        centerTitle: true,
        actions: [
            if (!_isReordering)
              TextButton.icon(
                onPressed: () => setState(() => _isReordering = true),
                icon: const Icon(Icons.sort),
                label: const Text('Ordenar'),
              )
            else
              TextButton.icon(
                onPressed: () => setState(() => _isReordering = false),
                icon: const Icon(Icons.check_circle_outline),
                label: const Text('Hecho'),
              ),
          IconButton(
            tooltip: 'Ir a inicio de sesión',
            icon: const Icon(Icons.person_outline),
            onPressed: () {
              context.go('/login');
            },
          ),
        ],
        ),
        body: ordersAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, st) => Center(child: Text('Error: $e')),
        data: (orders) {
          if (orders.isEmpty) {
              return const ResponsiveContainer(child: _EmptyState());
          }
            if (_isReordering && (role == UserRole.chofer1 || role == UserRole.chofer2)) {
              final assignee = role == UserRole.chofer1 ? 'chofer1' : 'chofer2';
              return ReorderableListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: orders.length,
                onReorder: (oldIndex, newIndex) async {
                  await ref.read(ordersProvider.notifier).reorderAssigned(assignee, oldIndex, newIndex);
                },
                itemBuilder: (context, index) {
                  final order = orders[index];
                  return GestureDetector(
                    key: ValueKey(order.id),
                    onLongPress: () {},
                    child: OrderCard(
                      order: order,
                      onComplete: () async {
                        final ok = await ref.read(ordersProvider.notifier).markDelivered(order.id);
                        if (!context.mounted) return;
                        if (ok) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text('Pedido ${order.id} entregado')),
                          );
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Error al enviar el webhook')),
                          );
                        }
                      },
                    ),
                  );
                },
              );
            }
            final width = MediaQuery.of(context).size.width;
            final isWide = width >= Breakpoints.desktop;
            if (!isWide) {
              return RefreshIndicator(
                onRefresh: () => ref.read(ordersProvider.notifier).refresh(),
                child: ListView.separated(
                  padding: const EdgeInsets.all(12),
                  itemBuilder: (context, index) {
                    final order = orders[index];
                    return GestureDetector(
                      onLongPress: () => setState(() => _isReordering = true),
                      child: OrderCard(
                      order: order,
                      onComplete: () async {
                        final ok = await ref.read(ordersProvider.notifier).markDelivered(order.id);
                        if (!context.mounted) return;
                        if (ok) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text('Pedido ${order.id} entregado')),
                          );
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: const Text('Error al enviar el webhook'),
                              action: SnackBarAction(
                                label: 'Reintentar',
                                onPressed: () {
                                  ref.read(ordersProvider.notifier).markDelivered(order.id);
                                },
                              ),
                            ),
                          );
                        }
                        },
                      ),
                    );
                  },
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemCount: orders.length,
                ),
              );
            }
            // Desktop grid
            final cross = width >= Breakpoints.largeDesktop ? 3 : 2;
            return ResponsiveContainer(
              child: RefreshIndicator(
                onRefresh: () => ref.read(ordersProvider.notifier).refresh(),
                child: GridView.builder(
                  padding: const EdgeInsets.all(12),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: cross,
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                    mainAxisExtent: 110,
                  ),
                  itemCount: orders.length,
                  itemBuilder: (context, index) {
                    final order = orders[index];
                    return OrderCard(
                      order: order,
                      onComplete: () async {
                        final ok = await ref.read(ordersProvider.notifier).markDelivered(order.id);
                        if (!context.mounted) return;
                        if (ok) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text('Pedido ${order.id} entregado')),
                          );
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: const Text('Error al enviar el webhook'),
                              action: SnackBarAction(
                                label: 'Reintentar',
                                onPressed: () {
                                  ref.read(ordersProvider.notifier).markDelivered(order.id);
                                },
                              ),
                            ),
                          );
                        }
                      },
                    );
                  },
                ),
              ),
            );
        },
        ),
        // FAB removed for chofer views; manager will have its own screen
        floatingActionButton: null,
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.local_shipping, size: 48),
          const SizedBox(height: 12),
          Text('No hay pedidos pendientes', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 4),
          const Text('Toca + para crear pedidos de ejemplo.'),
        ],
      ),
    );
  }
}

// FAB removed per requirement


