import 'dart:convert';
import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../constants/endpoints.dart';
import '../../auth/providers/role_providers.dart';

import '../data/order.dart';
import '../data/order_repository.dart';

final orderRepositoryProvider = Provider<OrderRepository>((ref) {
  return OrderRepository();
});

class OrdersController extends AsyncNotifier<List<Order>> {
  late final OrderRepository _repo;

  @override
  Future<List<Order>> build() async {
    _repo = ref.read(orderRepositoryProvider);
    return _repo.load();
  }

  Future<void> refresh() async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() => _repo.load());
  }

  Future<void> addDummy(int count) async {
    final updated = await _repo.generateDummy(count);
    state = AsyncData(updated);
  }

  Future<bool> markDelivered(String id) async {
    final updated = await _repo.markDelivered(id);
    state = AsyncData(updated);

    // Optimistic: try to POST webhook, but don't revert on failure
    try {
      final order = updated.firstWhere((o) => o.id == id);
      final uri = Uri.parse(completeOrderWebhookUrl);
      final client = HttpClient();
      final request = await client.postUrl(uri);
      request.headers.set(HttpHeaders.contentTypeHeader, 'application/json');
      request.add(utf8.encode(jsonEncode({
        'orderId': id,
        'status': 'delivered',
        'clientPhone': order.clientPhone,
        'clientName': order.clientName,
        'address': order.address,
      })));
      final response = await request.close();
      await response.drain();
      client.close();
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<void> addOrder(Order order) async {
    final updated = await _repo.addOrder(order);
    state = AsyncData(updated);
  }

  Future<void> updateOrder(Order order) async {
    final updated = await _repo.updateOrder(order);
    state = AsyncData(updated);
  }

  Future<void> assignOrder(String id, String? assignee) async {
    final updated = await _repo.assignOrder(id, assignee);
    state = AsyncData(updated);
  }

  Future<void> reorderAssigned(String? assignee, int oldIndex, int newIndex) async {
    // Normalize newIndex per ReorderableListView convention
    if (newIndex > oldIndex) newIndex -= 1;
    final current = await _repo.load();
    // Build list of indices for items assigned to this assignee in current order
    final assignedIndices = <int>[];
    for (int i = 0; i < current.length; i++) {
      final o = current[i];
      if (o.assignedTo == assignee) assignedIndices.add(i);
    }
    if (oldIndex < 0 || oldIndex >= assignedIndices.length || newIndex < 0 || newIndex >= assignedIndices.length) {
      return;
    }
    final from = assignedIndices[oldIndex];
    final to = assignedIndices[newIndex];
    final moved = current.removeAt(from);
    current.insert(to, moved);
    await _repo.save(current);
    state = AsyncData(current);
  }
}

final ordersProvider = AsyncNotifierProvider<OrdersController, List<Order>>(
  OrdersController.new,
);

final driverOrdersProvider = Provider<AsyncValue<List<Order>>>((ref) {
  final orders = ref.watch(ordersProvider);
  final role = ref.watch(roleProvider).value;
  return orders.whenData((list) {
    if (role == UserRole.chofer1) {
      return list.where((o) => o.assignedTo == 'chofer1').toList();
    }
    if (role == UserRole.chofer2) {
      return list.where((o) => o.assignedTo == 'chofer2').toList();
    }
    return list;
  });
});


