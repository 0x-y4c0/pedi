class Order {
  final String id;
  final String address;
  final double latitude;
  final double longitude;
  final String clientName;
  final String clientPhone;
  final bool delivered;
  final String? assignedTo; // 'chofer1', 'chofer2', or null

  const Order({
    required this.id,
    required this.address,
    required this.latitude,
    required this.longitude,
    required this.clientName,
    required this.clientPhone,
    required this.delivered,
    this.assignedTo,
  });

  Order copyWith({
    String? id,
    String? address,
    double? latitude,
    double? longitude,
    String? clientName,
    String? clientPhone,
    bool? delivered,
    String? assignedTo,
  }) {
    return Order(
      id: id ?? this.id,
      address: address ?? this.address,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
      clientName: clientName ?? this.clientName,
      clientPhone: clientPhone ?? this.clientPhone,
      delivered: delivered ?? this.delivered,
      assignedTo: assignedTo ?? this.assignedTo,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'address': address,
        'latitude': latitude,
        'longitude': longitude,
        'clientName': clientName,
        'clientPhone': clientPhone,
        'delivered': delivered,
        'assignedTo': assignedTo,
      };

  // JSON for Supabase (snake_case)
  Map<String, dynamic> toSupabaseJson() => {
        'id': id,
        'address': address,
        'latitude': latitude,
        'longitude': longitude,
        'client_name': clientName,
        'client_phone': clientPhone,
        'delivered': delivered,
        'assigned_to': assignedTo,
      };

  static Order fromJson(Map<String, dynamic> json) => Order(
        id: json['id'] as String,
        address: json['address'] as String,
        latitude: (json['latitude'] as num).toDouble(),
        longitude: (json['longitude'] as num).toDouble(),
        clientName: json['clientName'] as String,
        clientPhone: json['clientPhone'] as String,
        delivered: json['delivered'] as bool,
        assignedTo: json.containsKey('assignedTo') ? json['assignedTo'] as String? : null,
      );

  // From Supabase JSON (snake_case)
  static Order fromSupabaseJson(Map<String, dynamic> json) => Order(
        id: json['id'] as String,
        address: json['address'] as String,
        latitude: (json['latitude'] as num).toDouble(),
        longitude: (json['longitude'] as num).toDouble(),
        clientName: json['client_name'] as String,
        clientPhone: json['client_phone'] as String,
        delivered: json['delivered'] as bool,
        assignedTo: json['assigned_to'] as String?,
      );
}


