import 'dart:math';

class OrderProduct {
  final String name;
  final int quantity;
  const OrderProduct(this.name, this.quantity);
}

final List<String> _materials = [
  'Cemento',
  'Arena',
  'Piedra',
  'Cal',
  'Hierro',
  'Ladrillos',
  'Yeso',
  'Malla metálica',
  'Viguetas',
  'Cales finas',
];

List<OrderProduct> generateProductsForOrder(String orderId) {
  final seed = orderId.codeUnits.fold<int>(0, (a, b) => a + b);
  final rnd = Random(seed);
  final count = 3 + rnd.nextInt(4); // 3..6 items
  final used = <int>{};
  final items = <OrderProduct>[];
  for (int i = 0; i < count; i++) {
    int idx;
    do {
      idx = rnd.nextInt(_materials.length);
    } while (used.contains(idx));
    used.add(idx);
    final qty = 1 + rnd.nextInt(20); // 1..20
    items.add(OrderProduct(_materials[idx], qty));
  }
  return items;
}



