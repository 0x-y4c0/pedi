import 'dart:convert';
import 'package:lori_driver_app/utils/geo.dart';

import 'package:shared_preferences/shared_preferences.dart';

import 'order.dart';

class OrderRepository {
  static const String _prefsKey = 'orders';

  Future<List<Order>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonString = prefs.getString(_prefsKey);
    if (jsonString == null || jsonString.isEmpty) return [];
    final List<dynamic> decoded = json.decode(jsonString) as List<dynamic>;
    return decoded.map((e) => Order.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<void> save(List<Order> orders) async {
    final prefs = await SharedPreferences.getInstance();
    final encoded = json.encode(orders.map((o) => o.toJson()).toList());
    await prefs.setString(_prefsKey, encoded);
  }

  Future<List<Order>> generateDummy(int count) async {
    final current = await load();
    final now = DateTime.now().millisecondsSinceEpoch;
    final List<Order> added = List.generate(count, (i) {
      final id = (now + i).toString();
      final (lat, lng) = GeoUtils.randomBuenosAiresLatLng();
      return Order(
        id: id,
        address: '123 Main St, City ${(i + 1)}',
        latitude: lat,
        longitude: lng,
        clientName: 'Client ${(i + 1)}',
        clientPhone: '+5411000${(100 + i)}',
        delivered: false,
        assignedTo: null,
      );
    });
    final updated = [...current, ...added];
    await save(updated);
    return updated;
  }

  Future<List<Order>> markDelivered(String id) async {
    final current = await load();
    final updated = current
        .map((o) => o.id == id ? o.copyWith(delivered: true) : o)
        .toList();
    await save(updated);
    return updated;
  }

  Future<List<Order>> addOrder(Order order) async {
    final current = await load();
    final updated = [...current, order];
    await save(updated);
    return updated;
  }

  Future<List<Order>> updateOrder(Order updatedOrder) async {
    final current = await load();
    final updated = current.map((o) => o.id == updatedOrder.id ? updatedOrder : o).toList();
    await save(updated);
    return updated;
  }

  Future<List<Order>> assignOrder(String id, String? assignee) async {
    final current = await load();
    final updated = current.map((o) => o.id == id ? o.copyWith(assignedTo: assignee) : o).toList();
    await save(updated);
    return updated;
  }
}


