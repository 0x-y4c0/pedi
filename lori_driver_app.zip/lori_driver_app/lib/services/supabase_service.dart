import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../features/orders/data/order.dart';
import 'supabase_config.dart';

class SupabaseService {
  static SupabaseClient? _client;
  
  static SupabaseClient get client {
    if (_client == null) {
      throw Exception('Supabase not initialized. Call initialize() first.');
    }
    return _client!;
  }
  
  static Future<void> initialize() async {
    await Supabase.initialize(
      url: SupabaseConfig.supabaseUrl,
      anonKey: SupabaseConfig.supabaseAnonKey,
    );
    _client = Supabase.instance.client;
  }
  
  // Get all orders
  Future<List<Order>> getAllOrders() async {
    final response = await client
        .from('orders')
        .select()
        .order('created_at', ascending: false);
    
    return (response as List)
        .map((json) => Order.fromSupabaseJson(json as Map<String, dynamic>))
        .toList();
  }
  
  // Get orders for a specific driver
  Future<List<Order>> getOrdersForDriver(String? assignee) async {
    final query = client.from('orders').select();
    
    if (assignee != null) {
      query.eq('assigned_to', assignee);
    }
    
    final response = await query.order('created_at', ascending: false);
    
    return (response as List)
        .map((json) => Order.fromSupabaseJson(json as Map<String, dynamic>))
        .toList();
  }
  
  // Create a new order
  Future<Order> createOrder(Order order) async {
    final response = await client
        .from('orders')
        .insert(order.toSupabaseJson())
        .select()
        .single();
    
    return Order.fromSupabaseJson(response as Map<String, dynamic>);
  }
  
  // Update an order
  Future<Order> updateOrder(Order order) async {
    final response = await client
        .from('orders')
        .update(order.toSupabaseJson())
        .eq('id', order.id)
        .select()
        .single();
    
    return Order.fromSupabaseJson(response as Map<String, dynamic>);
  }
  
  // Mark order as delivered and trigger webhook
  Future<Order> markDelivered(String orderId) async {
    // First update the order
    final response = await client
        .from('orders')
        .update({'delivered': true})
        .eq('id', orderId)
        .select()
        .single();
    
    final order = Order.fromSupabaseJson(response as Map<String, dynamic>);
    
    // Trigger Edge Function to call Kapso API
    try {
      await client.functions.invoke(
        'notify-delivery',
        body: {
          'orderId': order.id,
          'clientPhone': order.clientPhone,
          'clientName': order.clientName,
          'address': order.address,
        },
      );
    } catch (e) {
      // Log error but don't fail the delivery update
      debugPrint('Error calling Kapso API: $e');
    }
    
    return order;
  }
  
  // Assign order to a driver
  Future<Order> assignOrder(String orderId, String? assignee) async {
    final response = await client
        .from('orders')
        .update({'assigned_to': assignee})
        .eq('id', orderId)
        .select()
        .single();
    
    return Order.fromSupabaseJson(response as Map<String, dynamic>);
  }
  
  // Reorder assigned orders (update sort_order field)
  Future<void> reorderAssigned(String? assignee, List<String> orderIds) async {
    // This updates the sort_order based on the new order
    for (int i = 0; i < orderIds.length; i++) {
      await client
          .from('orders')
          .update({'sort_order': i})
          .eq('id', orderIds[i]);
      
      if (assignee != null) {
        await client
            .from('orders')
            .update({'assigned_to': assignee})
            .eq('id', orderIds[i]);
      }
    }
  }
  
  // Listen to real-time changes
  RealtimeChannel getOrdersChannel() {
    return client.channel('orders_channel').onPostgresChanges(
      event: PostgresChangeEvent.all,
      schema: 'public',
      table: 'orders',
      callback: (payload) {
        // Handle real-time updates
        debugPrint('Orders changed: ${payload.toString()}');
      },
    );
  }
}

