// Supabase Configuration
// Your Supabase project credentials

class SupabaseConfig {
  // Your Supabase project URL
  static const String supabaseUrl = 'https://bbardxgyyeffrdhylfkv.supabase.co';
  
  // Your Supabase anon/public key
  static const String supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJiYXJkeGd5eWVmZnJkaHlsZmt2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjIzMDYzNTUsImV4cCI6MjA3Nzg4MjM1NX0.OHeYwhZd_yFR2vffoOXTpBZTHRKJ_aiLF4VQNjPC65I';
  
  // For Edge Functions (optional, for Kapso API integration)
  // Get this from Settings > API > service_role key (KEEP SECRET!)
  static const String supabaseServiceRoleKey = 'YOUR_SERVICE_ROLE_KEY_HERE'; // Keep this secret!
}

