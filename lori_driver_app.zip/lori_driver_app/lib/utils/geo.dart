import 'dart:math';

class GeoUtils {
  // Bounding box aproximado de CABA/Buenos Aires
  // Latitudes: [-34.75, -34.55]
  // Longitudes: [-58.55, -58.30]
  static final Random _rand = Random();

  static (double lat, double lng) randomBuenosAiresLatLng() {
    const double latMin = -34.75;
    const double latMax = -34.55;
    const double lngMin = -58.55;
    const double lngMax = -58.30;
    final lat = latMin + _rand.nextDouble() * (latMax - latMin);
    final lng = lngMin + _rand.nextDouble() * (lngMax - lngMin);
    return (lat, lng);
  }
}



