import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'features/onboarding/presentation/onboarding_page.dart';
import 'features/orders/presentation/orders_page.dart';
import 'features/settings/presentation/settings_page.dart';
import 'features/onboarding/providers/onboarding_providers.dart';
import 'features/auth/presentation/login_page.dart';
import 'features/auth/providers/role_providers.dart';
import 'features/manager/presentation/manager_page.dart';
import 'features/manager/presentation/order_details_page.dart';
import 'widgets/responsive.dart';

class App extends ConsumerWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final onboarding = ref.watch(onboardingDismissedProvider);
    final roleAsync = ref.watch(roleProvider);
    return onboarding.when(
      loading: () => const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      ),
      error: (e, st) => Scaffold(
        body: Center(child: Text('Error: $e')),
      ),
      data: (dismissed) {
        return roleAsync.when(
          loading: () => const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          ),
          error: (e, st) => Scaffold(body: Center(child: Text('Error: $e'))),
          data: (role) {
            final initialLocation = (role == null
                ? '/login'
                : (role == UserRole.manager ? '/manager' : '/orders'));

            final router = GoRouter(
              initialLocation: initialLocation,
              routes: [
                GoRoute(
                  path: '/onboarding',
                  builder: (context, state) => const OnboardingPage(),
                ),
                GoRoute(
                  path: '/login',
                  builder: (context, state) => const LoginPage(),
                ),
                GoRoute(
                  path: '/manager',
                  builder: (context, state) => const ManagerPage(),
                ),
                GoRoute(
                  path: '/manager/order/:id',
                  builder: (context, state) => ManagerOrderDetailsPage(orderId: state.pathParameters['id']!),
                ),
                ShellRoute(
                  builder: (context, state, child) => _TabsShell(child: child),
                  routes: [
                    GoRoute(
                      path: '/orders',
                      builder: (context, state) => const OrdersPage(),
                    ),
                    GoRoute(
                      path: '/settings',
                      builder: (context, state) => const SettingsPage(),
                    ),
                  ],
                ),
              ],
            );
            return MaterialApp.router(
              debugShowCheckedModeBanner: false,
              routerConfig: router,
            );
          },
        );
      },
    );
  }
}

class _TabsShell extends StatefulWidget {
  const _TabsShell({required this.child});
  final Widget child;

  @override
  State<_TabsShell> createState() => _TabsShellState();
}

class _TabsShellState extends State<_TabsShell> {
  int _indexFromLocation(String location) {
    if (location.startsWith('/settings')) return 1;
    return 0; // orders
  }

  void _onDestinationSelected(int index) {
    switch (index) {
      case 0:
        context.go('/orders');
        break;
      case 1:
        context.go('/settings');
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final loc = GoRouterState.of(context).uri.toString();
    final currentIndex = _indexFromLocation(loc);
    final width = MediaQuery.of(context).size.width;
    final isDesktop = width >= Breakpoints.desktop;
    if (!isDesktop) {
      return Scaffold(
        body: SafeArea(child: widget.child),
        bottomNavigationBar: NavigationBar(
          selectedIndex: currentIndex,
          onDestinationSelected: _onDestinationSelected,
          destinations: const [
            NavigationDestination(icon: Icon(Icons.list_alt_outlined), selectedIcon: Icon(Icons.list_alt), label: 'Pedidos'),
            NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Ajustes'),
          ],
        ),
      );
    }
    // Desktop layout: sidebar NavigationRail + content
    return Scaffold(
      body: SafeArea(
        child: Row(
          children: [
            NavigationRail(
              selectedIndex: currentIndex,
              labelType: NavigationRailLabelType.all,
              onDestinationSelected: (i) => _onDestinationSelected(i),
              destinations: const [
                NavigationRailDestination(
                  icon: Icon(Icons.list_alt_outlined),
                  selectedIcon: Icon(Icons.list_alt),
                  label: Text('Pedidos'),
                ),
                NavigationRailDestination(
                  icon: Icon(Icons.settings_outlined),
                  selectedIcon: Icon(Icons.settings),
                  label: Text('Ajustes'),
                ),
              ],
            ),
            const VerticalDivider(width: 1),
            Expanded(child: widget.child),
          ],
        ),
      ),
    );
  }
}


